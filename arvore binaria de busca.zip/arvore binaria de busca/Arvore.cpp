#include <queue>
#include <stack>
#include <stdlib.h>
#include <stdio.h>
#include "Arvore.h"
using namespace std;

Arv_bin* abb_cria(void){
    Arv_bin* arv =(Arv_bin*)malloc(sizeof(Arv_bin));
    arv->raiz = NULL;
    return arv;
}

void arv_imprime(Arv_bin* arv){
	arv_imprime_no(arv->raiz);
}
void arv_imprime_no(Nodo* raiz){
	if(raiz!=NULL){
		arv_imprime_no(raiz->esq);
		printf("%d\n", raiz->info);
		arv_imprime_no(raiz->dir);
	}
}

void arv_imprime_pre_ordem(Arv_bin* arv){
	arv_imprime_no_pre_ordem(arv->raiz);
}
void arv_imprime_no_pre_ordem(Nodo* raiz){
	printf("<");
	if(raiz!=NULL){
        printf("%d", raiz->info);
		arv_imprime_no_pre_ordem(raiz->esq);
		arv_imprime_no_pre_ordem(raiz->dir);
	}
	printf(">");
}

void arv_libera(Arv_bin* arv){
	arv_libera_no(arv->raiz);
}

void arv_libera_no(Nodo* raiz){
	if(raiz!=NULL){
		arv_libera_no(raiz->esq);
		arv_libera_no(raiz->dir);
		free(raiz);
	}
}

void abb_insere(Arv_bin* arv, int c){
	arv->raiz = insere_no(arv->raiz, c);
}

Nodo* insere_no(Nodo* raiz, int c){
	if(raiz==NULL){
		raiz = (Nodo*)malloc(sizeof(Nodo));
		raiz->info = c;
		raiz->esq = raiz->dir = NULL;
	}
	else if(c < raiz->info){
		raiz->esq = insere_no(raiz->esq, c);
	}
	else
		raiz->dir = insere_no(raiz->dir, c);
	return raiz;
}

void abb_remove(Arv_bin* arv, int c){
	arv->raiz = remove_no(arv->raiz, c);
}

Nodo* remove_no(Nodo* raiz, int c){
	if(raiz == NULL)
		return NULL;
	else if(c < raiz->info)
		raiz->esq = remove_no(raiz->esq, c);
	else if(c > raiz->info)
		raiz->dir = remove_no(raiz->dir, c);
	else{
		if(raiz->esq==NULL && raiz->dir==NULL){
			free(raiz);
			raiz = NULL;
		}
		else if(raiz->esq==NULL){
			Nodo *aux = raiz;
			raiz = raiz->dir;
			free(aux);
		}
		else if(raiz->dir==NULL){
			Nodo *aux = raiz;
			raiz = raiz->esq;
			free(aux);
		}
		else{
			Nodo *aux = raiz->esq;
			while(aux->dir!=NULL){
				aux = aux->dir;
			}
			raiz->info = aux->info;
			aux->info = c;
			raiz->esq = remove_no(raiz->esq, c);
		}
	}
	return raiz;
}

void abb_remove2(Arv_bin* arv, int c){
	arv->raiz = remove_no2(arv->raiz, c);
}

Nodo* remove_no2(Nodo* raiz, int c){
	if(raiz == NULL)
		return NULL;
	else if(c < raiz->info)
		raiz->esq = remove_no2(raiz->esq, c);
	else if(c > raiz->info)
		raiz->dir = remove_no2(raiz->dir, c);
	else{
		if(raiz->esq==NULL && raiz->dir==NULL){
			free(raiz);
			raiz = NULL;
		}
		else if(raiz->esq==NULL){
			Nodo *aux = raiz;
			raiz = raiz->dir;
			free(aux);
		}
		else if(raiz->dir==NULL){
			Nodo *aux = raiz;
			raiz = raiz->esq;
			free(aux);
		}
		else{
			Nodo *aux = raiz->dir;
			while(aux->esq!=NULL){
				aux = aux->esq;
			}
			raiz->info = aux->info;
			aux->info = c;
			raiz->dir = remove_no2(raiz->dir, c);
		}
	}
	return raiz;
}

int not_eh_busca(Arv_bin* arv){
	return not_eh_busca2(arv->raiz);
}

int not_eh_busca2(Nodo* raiz){
	if(raiz->dir == NULL && raiz->esq == NULL){
		return 0;
	}
	if((raiz->esq->info < raiz->info) || (raiz->dir->info >= raiz->info)){
		return 0;
	}
	if((raiz->esq->info >= raiz->info) || (raiz->dir->info < raiz->info)){
		return 1;
	}
	else{
		return not_eh_busca2(raiz->esq) + not_eh_busca2(raiz->dir);
	}
}

int Max_arv(Arv_bin* arv){
    return Max_arv2(arv->raiz);
}

int Max_arv2(Nodo* raiz){
    if(raiz->dir==NULL)
        return raiz->info;
    if(raiz!=NULL){
        return Max_arv2(raiz->dir);
    }
}


int Menor_arv(Arv_bin* arv){
    return Menor_arv2(arv->raiz);
}

int Menor_arv2(Nodo* raiz){
    Arv_bin *aux = abb_cria();
    aux->raiz = raiz;
    while(aux->raiz->esq!=NULL){
        aux->raiz = aux->raiz->esq;
    }
    return aux->raiz->info;
}


void k_esimo_termo(Nodo *r, int *k){
    if(r != NULL){
        k_esimo_termo(r->esq,k);
        (*k)--;
        if (*k == 0){
            printf("K-esimo termo: %d\n", r->info);
        }
        k_esimo_termo(r->dir,k);
    }
}

int compara_arvore(Arv_bin* arv1, Arv_bin* arv2){
	if(arv1==NULL && arv2!=NULL || arv1!=NULL && arv2==NULL)
		return 1;
	else if(arv1==NULL && arv2==NULL){
		return 0;
	}
	else
		return (compara_arvore2(arv1->raiz, arv2->raiz));
}

int compara_arvore2(Nodo* raiz1, Nodo* raiz2){
	if (raiz1 == NULL && raiz2 == NULL){
        return 0;
    }
    else if (raiz1 != NULL && raiz2 == NULL || raiz1 == NULL && raiz2 != NULL){
        return 1;
    }
    else if (raiz1->info != raiz2->info){
        return 1;
    } else{
        return compara_arvore2(raiz1->esq,raiz2->esq) + compara_arvore2(raiz1->dir,raiz2->dir);
	}
}

int no_com_um_filho(Arv_bin* arv){
    return no_com_um_filho2(arv->raiz);
}

int no_com_um_filho2(Nodo* raiz){
    if(raiz==NULL)
        return 0;
    else if(raiz->dir == NULL && raiz->esq == NULL)
        return 0;
    else if(raiz->dir == NULL && raiz->esq != NULL)
        return 1 + no_com_um_filho2(raiz->esq);
    else if (raiz->dir != NULL && raiz->esq == NULL)
        return 1 + no_com_um_filho2(raiz->dir);
    else
        return no_com_um_filho2(raiz->dir) + no_com_um_filho2(raiz->esq);
}
