#ifndef ARVORE_H_
#define ARVORE_H_
#include <stdlib.h>
#include <stdio.h>
#include "Arvore.h"
#include <queue>
#include <iostream>
using namespace std;

typedef struct no{
    int info;
    struct no *esq;
    struct no *dir;
}Nodo;

typedef struct arv_bin{
    Nodo *raiz;
}Arv_bin;

Arv_bin* abb_cria(void);
void arv_imprime(Arv_bin* arv);
void arv_imprime_no(Nodo* raiz);
void arv_imprime_pre_ordem(Arv_bin* arv);
void arv_imprime_no_pre_ordem(Nodo* raiz);
void arv_libera(Arv_bin* arv);
void arv_libera_no(Nodo* raiz);
void abb_insere(Arv_bin* arv, int c);
Nodo* insere_no(Nodo* raiz, int c);
void abb_remove(Arv_bin* arv, int c);
Nodo* remove_no(Nodo* raiz, int c);
void abb_remove2(Arv_bin* arv, int c);
Nodo* remove_no2(Nodo* raiz, int c);
int not_eh_busca(Arv_bin* arv);
int not_eh_busca2(Nodo* raiz);
int Max_arv(Arv_bin* arv);
int Max_arv2(Nodo* raiz);
int Menor_arv(Arv_bin* arv);
int Menor_arv2(Nodo* raiz);
void k_esimo_termo(Nodo *r, int *k);
int compara_arvore(Arv_bin* arv1, Arv_bin* arv2);
int compara_arvore2(Nodo* raiz1, Nodo* raiz2);
int no_com_um_filho(Arv_bin* arv);
int no_com_um_filho2(Nodo* raiz);

#endif // ARVORE_H_
