#include <stdlib.h>
#include <stdio.h>
#include "Arvore.h"
#include <queue>
#include <iostream>
using namespace std;

int main(){
    int ordem,quant, *new_arv, valor, aux,k;
    queue<int> vet;

	Arv_bin *arv = abb_cria();
	abb_insere(arv, 50);
	abb_insere(arv, 30);
	abb_insere(arv, 70);
	abb_insere(arv, 20);
	abb_insere(arv, 40);
	abb_insere(arv, 60);
	abb_insere(arv, 80);
	abb_insere(arv, 15);
	abb_insere(arv, 25);
	abb_insere(arv, 35);
	abb_insere(arv, 45);
	abb_insere(arv, 36);

	Arv_bin *arv2 = abb_cria();
	abb_insere(arv2, 50);
	abb_insere(arv2, 30);
	abb_insere(arv2, 70);
	abb_insere(arv2, 20);
	abb_insere(arv2, 40);
	abb_insere(arv2, 60);
	abb_insere(arv2, 80);
	abb_insere(arv2, 15);
	abb_insere(arv2, 25);
	abb_insere(arv2, 35);
	abb_insere(arv2, 45);
	abb_insere(arv2, 36);

	if(not_eh_busca(arv)){
		printf("Nao eh de busca\n");
	}
	else{
		printf("eh de busca\n");
	}
	arv_imprime_pre_ordem(arv);
	printf("\n");
	printf("Maior valor da arvore: %d\n",Max_arv(arv));
	printf("Menor valor da arvore: %d\n",Menor_arv(arv));
	if(!compara_arvore(arv,arv2)){
		printf("Sao iguais\n");
	}
	else{
		printf("Nao sao iguais\n");
	}
	//9-Construa uma �rvore bin�ria de busca dado o seu percurso em pr�-ordem.
	int amount,i,value;
	printf("Digite quantos valores vao ser inseridos para construcao da nova arvore:\n");
    scanf(" %d",&amount);
    Arv_bin *arv3 = abb_cria();
    for(i = 0; i < amount; i++){
        scanf("%d",&value);
        abb_insere(arv3,value);
    }
    arv_imprime_pre_ordem(arv3);

    //10-Verifique se uma subsequ�ncia ordenada faz parte de uma �rvore de busca bin�ria.
    printf("\nDigite a quantidade de valores da subsquencia:\n");
    scanf("%d",&quant);
    printf("Digite uma subsequencia ordenada:\n");
    for (i = 0; i < quant; i++){
        scanf("%d",&aux);
        vet.push(aux);
    }

    printf("Digite um valor k para ser procurado o k-esimo menor valor na arvore: ");
    cin >> k;
    k_esimo_termo(arv->raiz, &k);
    arv_libera(arv);
    arv_libera(arv2);
    arv_libera(arv3);

	return 0;
}


